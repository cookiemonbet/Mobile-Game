package com.example.save_the_plushy;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class LeaderBoardRVAdapter extends RecyclerView.Adapter<LeaderBoardRVAdapter.ViewHolder> {

    private static final int VIEW_TYPE_HEADER = 1;
    private static final int VIEW_TYPE_ITEM = 2;

    private ArrayList<LeaderboardModal> leaderboardModalArrayList;
    private Context context;

    // constructor
    public LeaderBoardRVAdapter(ArrayList<LeaderboardModal> leaderboardModalArrayList, Context context) {
        this.leaderboardModalArrayList = leaderboardModalArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_HEADER) {
            // For header view type, inflate the leaderboard_rv_item_header.xml layout.
            View headerView = LayoutInflater.from(parent.getContext()).inflate(R.layout.leaderboard_rv_item_header, parent, false);
            return new ViewHolder(headerView, viewType); // Pass the view type to the constructor.
        } else {
            // For item view type, inflate the leaderboard_rv_item.xml layout.
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.leaderboard_rv_item, parent, false);
            return new ViewHolder(view, viewType); // Pass the view type to the constructor.
        }
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        LeaderboardModal modal = leaderboardModalArrayList.get(position);
        if (holder.viewType == VIEW_TYPE_HEADER) {
            // If it's a header view, set the text to be empty.
            holder.positionTV.setText("");
        } else {
            // If it's an item view, display the actual position.
            holder.positionTV.setText(String.valueOf(modal.getPosition()));
        }

        holder.userNameTV.setText(modal.getUserName());
        holder.scoreTV.setText(modal.getScore());
    }

    @Override
    public int getItemCount() {
        // returning the size of our array list
        return leaderboardModalArrayList.size();
    }

    @Override
    public int getItemViewType(int position) {
        // Check if it's the first position (header row) and return the appropriate view type.
        return position == 0 ? VIEW_TYPE_HEADER : VIEW_TYPE_ITEM;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        // creating variables for our text views.
        private TextView positionTV, userNameTV, scoreTV;
        private int viewType; // Store the view type in the ViewHolder.

        public ViewHolder(@NonNull View itemView, int viewType) {
            super(itemView);
            this.viewType = viewType; // Save the view type to use later.

            if (this.viewType == VIEW_TYPE_HEADER) {
                // If the view is the header, find views accordingly.
                positionTV = itemView.findViewById(R.id.idLeaderBoardTVHeaderPosition);
                userNameTV = itemView.findViewById(R.id.idLeaderBoardTVHeaderUserName);
                scoreTV = itemView.findViewById(R.id.idLeaderBoardTVHeaderScore);
            } else {
                // If the view is an item, find views accordingly.
                userNameTV = itemView.findViewById(R.id.idLeaderBoardTVUserName);
                scoreTV = itemView.findViewById(R.id.idLeaderBoardTVScore);
                positionTV = itemView.findViewById(R.id.idLeaderBoardTVPosition);
            }
        }
    }
}
