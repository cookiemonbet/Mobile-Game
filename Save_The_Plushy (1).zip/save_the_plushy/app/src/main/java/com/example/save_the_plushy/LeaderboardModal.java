package com.example.save_the_plushy;

public class LeaderboardModal {
    // variables for our coursename,
    // description, tracks and duration, id.
    private String userName;
    private int position;
    private String score;
    private int id;

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }
    public String getUserName() { return userName; }

    public void setUserName(String userName)
    {
        this.userName = userName;
    }

    public String getScore()
    {
        return score;
    }

    public void setScore(String score)
    {
        this.score = score;
    }

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    // constructor
    public LeaderboardModal(String userName,
                       String score)
    {
        this.userName = userName;
        this.score = score;
    }
}
