package com.example.save_the_plushy;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.util.Random;

public class Angryplushy {
    Bitmap angryplushy[] = new Bitmap[2];
    int angryplushyFrame = 0;
    int angryplushyX, angryplushyY, angryplushyVelocity;
    Random random;

    public Angryplushy(Context context){
        angryplushy[0] = BitmapFactory.decodeResource(context.getResources(), R.drawable.angry_plushy);
        random = new Random();
        resetPosition();
    }

    public Bitmap getAngryplushy(int angryplushyFrame){
        return angryplushy[angryplushyFrame];
    }

    public int getAngryplushyWidth(){
        return angryplushy[0].getWidth();
    }

    public int getAngryplushyHeight(){
        return angryplushy[0].getHeight();
    }

    public void resetPosition(){
        angryplushyX = random.nextInt(GameView.dWidth - getAngryplushyWidth());
        angryplushyY = -5000 + random.nextInt(5000) * -1;
        angryplushyVelocity = 15 + random.nextInt(8);
    }
}

