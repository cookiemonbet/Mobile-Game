package com.example.save_the_plushy;

import static com.example.save_the_plushy.MainActivity.name;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Objects;

public class GameOver extends AppCompatActivity {

    private Button btnOpenLeaderboard;
    TextView tvPoints;
    TextView tvHighest;
    SharedPreferences sharedPreferences;
    ImageView ivNewHighest;
    private DBHandler dbHandler;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_over);

        btnOpenLeaderboard = findViewById(R.id.BtnOpenLeaderboard);

        tvPoints = findViewById(R.id.tvPoints);
        tvHighest = findViewById(R.id.tvHighest);
        TextView highestPlayer = findViewById(R.id.tvHighestPlayer);
        ivNewHighest = findViewById(R.id.ivNewHighest);
        int points = getIntent().getExtras().getInt("points");
        tvPoints.setText("" + points);

        sharedPreferences = getSharedPreferences("my_pref", 0);
        int highest = sharedPreferences.getInt("highest", 0);
        String bestPlayer = sharedPreferences.getString("bestPlayer", "Anonymous");

        if(Objects.equals(name, "Quby")){
            dbHandler = new DBHandler(GameOver.this);
            dbHandler.addNewUser("CrazyHacks", Integer.toString(points));
        }else{
            dbHandler = new DBHandler(GameOver.this);
            dbHandler.addNewUser(name, Integer.toString(points));
        }

        if (points > highest){
            ivNewHighest.setVisibility(View.VISIBLE);
            highest = points;
            bestPlayer = name;
            SharedPreferences.Editor editor = sharedPreferences.edit();
            if(Objects.equals(name, "Quby")){
                editor.putInt("highest", highest);
                editor.putString("bestPlayer", "CrazyHacks");
                editor.commit();
            } else {
                editor.putInt("highest", highest);
                editor.putString("bestPlayer", name);
                editor.commit();
            }

        }
        tvHighest.setText("" + highest);
        if(Objects.equals(name, "Quby")){
            highestPlayer.setText("" + "CrazyHacks");
        } else {
            highestPlayer.setText("" + bestPlayer);
        }


        btnOpenLeaderboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent i = new Intent(GameOver.this, ViewLeaderboard.class);
                startActivity(i);
            }
        });
    }

    public void restart(View view){
        Intent intent = new Intent(GameOver.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    public void exit(View view){
        finish();
    }


}
