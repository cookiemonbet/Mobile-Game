package com.example.save_the_plushy;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    public static String name = "Anonymous";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Objects.equals(name, "Quby")) {
            showPointsToast("Hi " + "CrazyHacks" + "!", R.drawable.orange_plushy_small);
        }
        else showPointsToast("Hi " + name + "!", R.drawable.orange_plushy_small);


    }

    public void startGame(View view) {
        GameView gameView = new GameView(this, name);
        setContentView(gameView);
    }

    public void btn_showMessage(View view){

        final AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
        View mView = getLayoutInflater().inflate(R.layout.custom_dialog,null);
        final EditText txt_inputText = (EditText)mView.findViewById(R.id.txt_input);
        Button btn_cancel = (Button)mView.findViewById(R.id.btn_cancel);
        Button btn_okay = (Button)mView.findViewById(R.id.btn_okay);
        alert.setView(mView);
        final AlertDialog alertDialog = alert.create();
        alertDialog.setCanceledOnTouchOutside(false);
        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });
        btn_okay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = txt_inputText.getText().toString();
                alertDialog.dismiss();
                if (Objects.equals(name, "Quby")) {
                    showPointsToast("Hi " + "CrazyHacks" + "!", R.drawable.orange_plushy_small);
                }
                else{
                    showPointsToast("Hi " + name + "!", R.drawable.orange_plushy_small);
                }
            }
        });
        alertDialog.show();
    }

    private void showPointsToast(String message, int ResourceId) {
        // Inflate the custom layout for the toast
        View toastView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.toast_layout, null);

        // Get references to the ImageView and TextView in the custom layout
        ImageView imageView = toastView.findViewById(R.id.imageView);
        TextView textView = toastView.findViewById(R.id.textView);
        imageView.setImageResource(ResourceId);
        textView.setText(message);


        // Create and display the custom toast
        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setView(toastView);
        toast.setGravity(Gravity.TOP, 0, 0);
        toast.show();
    }

}


