package com.example.save_the_plushy;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.util.Random;

public class Heart {
    Bitmap heart[] = new Bitmap[2];
    int heartFrame = 0;
    int heartX, heartY, heartVelocity;
    Random random;

    public Heart(Context context){
        heart[0] = BitmapFactory.decodeResource(context.getResources(), R.drawable.heart1);
        heart[1] = BitmapFactory.decodeResource(context.getResources(), R.drawable.heart2);
        random = new Random();
        resetPosition();
    }

    public Bitmap getHeart(int heartFrame){
        return heart[heartFrame];
    }

    public int getHeartWidth(){
        return heart[0].getWidth();
    }

    public int getHeartHeight(){
        return heart[0].getHeight();
    }


    public void resetPosition(){
        heartX = random.nextInt(GameView.dWidth - getHeartWidth());
        heartY = -1200 + random.nextInt(600) * -1;
        heartVelocity = 5 + random.nextInt(40);
    }

}
