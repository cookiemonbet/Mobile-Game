package com.example.save_the_plushy;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.util.Random;

public class Bubble {
    Bitmap bubble[] = new Bitmap[2];
    int bubbleFrame = 0;
    int bubbleX, bubbleY, bubbleVelocity;
    Random random;

    public Bubble(Context context) {
        bubble[0] = BitmapFactory.decodeResource(context.getResources(), R.drawable.bubble1);
        bubble[1] = BitmapFactory.decodeResource(context.getResources(), R.drawable.bubble2);
        random = new Random();
        resetPosition();
    }

    public Bitmap getBubble(int bubbleFrame) {
        return bubble[bubbleFrame];
    }

    public int getBubbleWidth() {
        return bubble[0].getWidth();
    }

    public int getBubbleHeight() {
        return bubble[0].getHeight();
    }

    public void resetPosition() {
        bubbleX = random.nextInt(GameView.dWidth - getBubbleWidth());
        bubbleY = -1200 + random.nextInt(600) * -1;
        bubbleVelocity = 5 + random.nextInt(40);
    }
}