package com.example.save_the_plushy;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Point;
import android.media.MediaPlayer;
import android.view.Display;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.graphics.Bitmap;
import android.os.Handler;
import android.graphics.Rect;
import android.graphics.Paint;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.res.ResourcesCompat;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Random;

public class GameView extends View {

    String username;
    Bitmap background, ground, plushy;
    Rect rectBackground, rectGround;
    Context context;
    Handler handler;
    final long UPDATE_MILLIS = 30;
    Runnable runnable;
    Paint textPaint = new Paint();
    Paint healthPaint = new Paint();
    float TEXT_SIZE = 120;
    int points = 0;
    int life = 3;
    static int dWidth, dHeight;
    Random random;
    float plushyX, plushyY;
    float oldX;
    float oldPlushyX;
    ArrayList<Bomb> bombs;
    ArrayList<Explosion> explosions;
    ArrayList<Heart> hearts;
    ArrayList<Quby> qubies;
    ArrayList<Angryplushy> angryplushies;
    ArrayList<Bubble> bubbles;
    private boolean isPlushyInitialPositionSet = false;
    private boolean plushyBubble = false;
    private float targetPlushyY;
    private float plushyYVelocity = 5;

    ArrayList<Purplushy> purplushies;
    MediaPlayer backgroundMusic;
    private boolean isGameOver = false;
    int level = 1;

    public GameView(Context context, String username) {
        super(context);
        this.context = context;
        this.username = username;
        background = BitmapFactory.decodeResource(getResources(), R.drawable.background);
        ground = BitmapFactory.decodeResource(getResources(), R.drawable.ground);
        plushy = BitmapFactory.decodeResource(getResources(), R.drawable.orange_plushy_small);
        Display display = ((Activity) getContext()).getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        dWidth = size.x;
        dHeight = size.y;
        rectBackground = new Rect(0,0,dWidth, dHeight);
        rectGround = new Rect(0, dHeight - ground.getHeight(), dWidth, dHeight);
        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                if (!isGameOver) {
                    invalidate();
                }
            }
        };
        textPaint.setColor(Color.rgb(255, 165, 0));
        textPaint.setTextSize(TEXT_SIZE);
        textPaint.setTextAlign(Paint.Align.LEFT);
        textPaint.setTypeface(ResourcesCompat.getFont(context, R.font.kenney_blocks));
        healthPaint.setColor(Color.GREEN);
        random = new Random();
        plushyX = dWidth / 2 - plushy.getWidth() / 2;
        plushyY = dHeight - ground.getHeight() - plushy.getHeight();
        bombs = new ArrayList<>();
        explosions = new ArrayList<>();
        hearts = new ArrayList<>();
        qubies = new ArrayList<>();
        angryplushies = new ArrayList<>();
        purplushies = new ArrayList<>();
        bubbles = new ArrayList<>();
        targetPlushyY = dHeight - ground.getHeight() - plushy.getHeight();

        if (username.equals("Quby")){
            showPointsToast(1000, "You are a crazy Quby",R.drawable.quby);
            level = 5;
            for (int i=0; i<20; i++){
                Quby quby = new Quby(context);
                quby.setQubyY(-200);
                qubies.add(quby);
            }
        }else {
            for (int i=0; i<3; i++){
                Bomb bomb = new Bomb(context);
                bombs.add(bomb);
            }
        }

        for (int i=0; i<1; i++){
            Heart heart = new Heart(context);
            hearts.add(heart);
        }

        for (int i=0; i<1; i++){
            Quby quby = new Quby(context);
            qubies.add(quby);
        }

        for (int i=0; i<1; i++){
            Purplushy purplushy = new Purplushy(context);
            purplushies.add(purplushy);
        }

        for (int i=0; i<1; i++){
            Bubble bubble = new Bubble(context);
            bubbles.add(bubble);
        }

        backgroundMusic = MediaPlayer.create(context, R.raw.angry_birds);
        backgroundMusic.setLooping(true);

    }
    @Override
    protected void onDraw(Canvas canvas){

        if (!backgroundMusic.isPlaying()) {
            backgroundMusic.start();
        }

        super.onDraw(canvas);
        canvas.drawBitmap(background, null, rectBackground, null);
        canvas.drawBitmap(ground, null, rectGround, null);
        canvas.drawBitmap(plushy, plushyX, plushyY, null);
        for (int i=0; i<bombs.size(); i++){
            canvas.drawBitmap(bombs.get(i).getBomb(bombs.get(i).bombFrame), bombs.get(i).bombX, bombs.get(i).bombY, null);
            bombs.get(i).bombFrame++;
            if (bombs.get(i).bombFrame > 1){
                bombs.get(i).bombFrame = 0;
            }
            bombs.get(i).bombY += bombs.get(i).bombVelocity;
            if (bombs.get(i).bombY + bombs.get(i).getBombHeight() >= dHeight - ground.getHeight()){
                points += 10;
                Explosion explosion = new Explosion(context);
                explosion.explosionX = bombs.get(i).bombX;
                explosion.explosionY = bombs.get(i).bombY;
                explosions.add(explosion);
                bombs.get(i).resetPosition();
            }
        }

        for (int i=0; i<hearts.size(); i++){
            canvas.drawBitmap(hearts.get(i).getHeart(hearts.get(i).heartFrame), hearts.get(i).heartX, hearts.get(i).heartY, null);
            hearts.get(i).heartFrame++;
            if (hearts.get(i).heartFrame > 1){
                hearts.get(i).heartFrame = 0;
            }
            hearts.get(i).heartY += hearts.get(i).heartVelocity;
            if (hearts.get(i).heartY + hearts.get(i).getHeartHeight() >= dHeight - ground.getHeight()){
                hearts.get(i).resetPosition();
            }
        }

        for (int i = 0; i < bubbles.size(); i++) {
            canvas.drawBitmap(bubbles.get(i).getBubble(bubbles.get(i).bubbleFrame), bubbles.get(i).bubbleX, bubbles.get(i).bubbleY, null);
            bubbles.get(i).bubbleFrame++;
            if (bubbles.get(i).bubbleFrame > 1) {
                bubbles.get(i).bubbleFrame = 0;
            }
            bubbles.get(i).bubbleY += bubbles.get(i).bubbleVelocity;
            if (bubbles.get(i).bubbleY + bubbles.get(i).getBubbleHeight() >= dHeight - ground.getHeight()) {
                bubbles.get(i).resetPosition();
            }
        }

        for (int i = 0; i < qubies.size(); i++) {
            canvas.drawBitmap(qubies.get(i).getQuby(qubies.get(i).qubyFrame), qubies.get(i).qubyX, qubies.get(i).qubyY, null);
            qubies.get(i).qubyFrame++;
            qubies.get(i).qubyFrame = 0;

            qubies.get(i).qubyY += qubies.get(i).qubyVelocity;
            if (qubies.get(i).qubyY + qubies.get(i).getQubyHeight() >= dHeight - ground.getHeight()) {
                qubies.get(i).resetPosition(200);
            }
        }

        for (int i = 0; i < purplushies.size(); i++) {
            canvas.drawBitmap(purplushies.get(i).getPurplushy(purplushies.get(i).purplushyFrame), purplushies.get(i).purplushyX, purplushies.get(i).purplushyY, null);
            purplushies.get(i).purplushyFrame++;
            purplushies.get(i).purplushyFrame = 0;

            purplushies.get(i).purplushyY += purplushies.get(i).purplushyVelocity;
            if (purplushies.get(i).purplushyY + purplushies.get(i).getPurplushyHeight() >= dHeight - ground.getHeight()) {
                purplushies.get(i).resetPosition();
            }
        }

        for (int i = 0; i < angryplushies.size(); i++) {
            canvas.drawBitmap(angryplushies.get(i).getAngryplushy(angryplushies.get(i).angryplushyFrame), angryplushies.get(i).angryplushyX, angryplushies.get(i).angryplushyY, null);
            angryplushies.get(i).angryplushyFrame++;
            angryplushies.get(i).angryplushyFrame = 0;

            angryplushies.get(i).angryplushyY += angryplushies.get(i).angryplushyVelocity;
            if (angryplushies.get(i).angryplushyY + angryplushies.get(i).getAngryplushyHeight() >= dHeight - ground.getHeight()) {
                angryplushies.get(i).resetPosition();
            }
        }


        for (int i=0; i < bombs.size(); i++){
            if (bombs.get(i).bombX + bombs.get(i).getBombWidth() >= plushyX
            && bombs.get(i).bombX <= plushyX + plushy.getWidth()
            && bombs.get(i).bombY + bombs.get(i).getBombWidth() >= plushyY
            && bombs.get(i).bombY + bombs.get(i).getBombWidth() <= plushyY + plushy.getHeight()){
                MediaPlayer bmp = MediaPlayer.create(context, R.raw.explosion);
                bmp.start();
                bmp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mediaPlayer) {
                        mediaPlayer.release();
                    }
                });
                life--;
                bombs.get(i).resetPosition();
                if (life <= 0) {
                    gameOver();
                }
            }
        }

        for (int i=0; i < hearts.size(); i++){
            if (hearts.get(i).heartX + hearts.get(i).getHeartWidth() >= plushyX
                    && hearts.get(i).heartX <= plushyX + plushy.getWidth()
                    && hearts.get(i).heartY + hearts.get(i).getHeartWidth() >= plushyY
                    && hearts.get(i).heartY + hearts.get(i).getHeartWidth() <= plushyY + plushy.getHeight()){
                points += 25;
                MediaPlayer hmp = MediaPlayer.create(context, R.raw.heart);
                hmp.setVolume(1.0f, 1.0f);
                hmp.start();
                if (life < 3) {
                    life++;
                }
                hearts.get(i).resetPosition();
            }
        }

        for (int i = 0; i < bubbles.size(); i++) {
            if (bubbles.get(i).bubbleX + bubbles.get(i).getBubbleWidth() >= plushyX
                    && bubbles.get(i).bubbleX <= plushyX + plushy.getWidth()
                    && bubbles.get(i).bubbleY + bubbles.get(i).getBubbleHeight() >= plushyY
                    && bubbles.get(i).bubbleY + bubbles.get(i).getBubbleHeight() <= plushyY + plushy.getHeight()) {
                MediaPlayer hmp = MediaPlayer.create(context, R.raw.bubbles );
                hmp.setVolume(1.0f, 1.0f);
                hmp.start();
                if (plushyBubble == false){
                    targetPlushyY = plushyY - 150;;
                    plushyBubble = true;
                } else {
                    targetPlushyY = plushyY + 150;
                    plushyBubble = false;
                }
                bubbles.get(i).resetPosition();
            }
        }

        if (isPlushyInitialPositionSet) {
            // Move plushy towards the target position
            if (plushyY < targetPlushyY) {
                plushyY += plushyYVelocity;
                if (plushyY > targetPlushyY) {
                    plushyY = targetPlushyY;
                }
            } else if (plushyY > targetPlushyY) {
                plushyY -= plushyYVelocity;
                if (plushyY < targetPlushyY) {
                    plushyY = targetPlushyY;
                }
            }
        } else {
            // Set the initial plushy position at the start of the game
            plushyY = targetPlushyY;
            isPlushyInitialPositionSet = true;
        }

        for (int i = 0; i < qubies.size(); i++) {
            if (qubies.get(i).qubyX + qubies.get(i).getQubyWidth() >= plushyX
                    && qubies.get(i).qubyX <= plushyX + plushy.getWidth()
                    && qubies.get(i).qubyY + qubies.get(i).getQubyWidth() >= plushyY
                    && qubies.get(i).qubyY + qubies.get(i).getQubyWidth() <= plushyY + plushy.getHeight()) {
                points += 100;
                MediaPlayer qmp = MediaPlayer.create(context, R.raw.quby);
                qmp.setVolume(1.0f, 1.0f);
                qmp.start();
                qubies.get(i).resetPosition(200);
            }
        }

        for (int i = 0; i < purplushies.size(); i++) {
            if (purplushies.get(i).purplushyX + purplushies.get(i).getPurplushyWidth() >= plushyX
                    && purplushies.get(i).purplushyX <= plushyX + plushy.getWidth()
                    && purplushies.get(i).purplushyY + purplushies.get(i).getPurplushyWidth() >= plushyY
                    && purplushies.get(i).purplushyY + purplushies.get(i).getPurplushyWidth() <= plushyY + plushy.getHeight()) {

                int purplushyPoints = (random.nextInt(10) + 1) * 100;
                points += purplushyPoints;
                showPointsToast(purplushyPoints, "purpleplushy", R.drawable.purple_plushy);
                life = 3;
                MediaPlayer pmp = MediaPlayer.create(context, R.raw.purple_plushy);
                pmp.setVolume(1.0f, 1.0f);
                pmp.start();
                purplushies.get(i).resetPosition();
            }
        }

        for (int i = 0; i < angryplushies.size(); i++) {
            if (angryplushies.get(i).angryplushyX + angryplushies.get(i).getAngryplushyWidth() >= plushyX
                    && angryplushies.get(i).angryplushyX <= plushyX + plushy.getWidth()
                    && angryplushies.get(i).angryplushyY + angryplushies.get(i).getAngryplushyWidth() >= plushyY
                    && angryplushies.get(i).angryplushyY + angryplushies.get(i).getAngryplushyWidth() <= plushyY + plushy.getHeight()) {

                int angryplushyPoints = (random.nextInt(10) + 1) * 100;
                points -= angryplushyPoints;
                showPointsToast(angryplushyPoints, "angryplushy", R.drawable.angry_plushy);
                life -= 1;
                MediaPlayer apmp = MediaPlayer.create(context, R.raw.angry_plushy);
                apmp.setVolume(1.0f, 1.0f);
                apmp.start();
                angryplushies.get(i).resetPosition();
            }
        }


        for (int i=0; i<explosions.size(); i++){
            canvas.drawBitmap(explosions.get(i).getExplosion(explosions.get(i).explosionFrame), explosions.get(i).explosionX,
                    explosions.get(i).explosionY, null);
            explosions.get(i).explosionFrame++;
            if (explosions.get(i).explosionFrame > 7){
                explosions.remove(i);
            }
        }

        if (life == 3){
            healthPaint.setColor(Color.GREEN);
        } else if (life == 2){
            healthPaint.setColor(Color.YELLOW);
        } else if (life == 1){
            healthPaint.setColor(Color.RED);
        }

        canvas.drawRect(dWidth-200, 30, dWidth-200+60*life, 80, healthPaint);
        canvas.drawText("" + points, 20, TEXT_SIZE, textPaint);
        handler.postDelayed(runnable, UPDATE_MILLIS);

        if (level == 1 && points > 500){
            Bomb bomb = new Bomb(context);
            bombs.add(bomb);
            Angryplushy angryplushy = new Angryplushy(context);
            angryplushies.add(angryplushy);
            level = 2;
        } else if (level == 2 && points > 1500){
            Bomb bomb = new Bomb(context);
            bombs.add(bomb);
            Angryplushy angryplushy = new Angryplushy(context);
            angryplushies.add(angryplushy);
            level = 3;
        } else if (level == 3 && points > 3000){
            Bomb bomb = new Bomb(context);
            bombs.add(bomb);
            Angryplushy angryplushy = new Angryplushy(context);
            angryplushies.add(angryplushy);
            level = 4;
        }
    }

    private boolean isTapOnPlushy(float x, float y) {
        // Replace 'plushyX', 'plushyY', and 'plushyWidth', 'plushyHeight' with actual values of your plushy's position and size.
        return x >= plushyX && x <= plushyX + plushy.getWidth() && y >= plushyY && y <= plushyY + plushy.getHeight();
    }

    private int tapCount = 0;
    private static final long TRIPLE_TAP_DELAY = 500; // 500 milliseconds for quintuple tap detection
    private Handler tapHandler = new Handler();
    private Runnable tapResetRunnable = new Runnable() {
        @Override
        public void run() {
            if (tapCount == 4) {
                gameOver();
            }
            tapCount = 0;
        }
    };

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float touchX = event.getX();
        float touchY = event.getY();
        if (touchY >= plushyY) {
            int action = event.getAction();
            if (action == MotionEvent.ACTION_DOWN) {
                oldX = event.getX();
                oldPlushyX = plushyX;

                // Increment the tap count and start the handler for reset
                tapCount++;
                tapHandler.removeCallbacks(tapResetRunnable);
                tapHandler.postDelayed(tapResetRunnable, TRIPLE_TAP_DELAY);
            } else if (action == MotionEvent.ACTION_MOVE) {
                float shift = oldX - touchX;
                float newPlushyX = oldPlushyX - shift;
                if (newPlushyX <= 0) {
                    plushyX = 0;
                } else if (newPlushyX >= dWidth - plushy.getWidth()) {
                    plushyX = dWidth - plushy.getWidth();
                } else {
                    plushyX = newPlushyX;
                }
            }
        }
        return true;
    }

    public void stopBackgroundMusic() {
        if (backgroundMusic != null) {
            backgroundMusic.stop();
            backgroundMusic.release();
            backgroundMusic = null;
        }
    }

    private void gameOver() {
        if (!isGameOver) {
            isGameOver = true;

            // Your existing game over logic here
            // Stop background music, show game over dialog, etc.

            stopBackgroundMusic();

            Intent intent = new Intent(context, GameOver.class);
            intent.putExtra("points", points);
            context.startActivity(intent);
            ((Activity) context).finish();
        }
    }

    private void showPointsToast(int points, String message, int ResourceId) {
        // Inflate the custom layout for the toast
        View toastView = LayoutInflater.from(getContext()).inflate(R.layout.toast_layout, null);

        // Get references to the ImageView and TextView in the custom layout
        ImageView imageView = toastView.findViewById(R.id.imageView);
        TextView textView = toastView.findViewById(R.id.textView);

        // Set the image and text in the custom toast
        if (Objects.equals(message, "purpleplushy")) {
            imageView.setImageResource(ResourceId);
            int randomNumber = random.nextInt(3) + 1;
            if (randomNumber == 1) {
                textView.setText("Go go Plushy! + " + points + " points");
            } else if (randomNumber == 2) {
                textView.setText("Keep it up! + " + points + " points");
            } else if (randomNumber == 3) {
                textView.setText("ORANGE PLUSHY! + " + points + " points");
            }
        } else if (Objects.equals(message, "angryplushy")) {
            imageView.setImageResource(ResourceId);
            int randomNumber = random.nextInt(3) + 1;
            if (randomNumber == 1) {
                textView.setText("ANGRY PLUSHY - " + points + " points");
            } else if (randomNumber == 2) {
                textView.setText("I AM ANGRY!!! - " + points + " points");
            } else if (randomNumber == 3) {
                textView.setText("ROARRRR + - " + points + " points");
            }
        } else{
            textView.setText(message);
        }


        // Create and display the custom toast
        Toast toast = new Toast(getContext());
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setView(toastView);
        toast.setGravity(Gravity.TOP, 0, 0);
        toast.show();
    }
}