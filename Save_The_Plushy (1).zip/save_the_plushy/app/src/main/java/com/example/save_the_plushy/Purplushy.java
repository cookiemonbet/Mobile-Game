package com.example.save_the_plushy;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.util.Random;

public class Purplushy {
    Bitmap purplushy[] = new Bitmap[2];
    int purplushyFrame = 0;
    int purplushyX, purplushyY, purplushyVelocity;
    Random random;

    public Purplushy(Context context){
        purplushy[0] = BitmapFactory.decodeResource(context.getResources(), R.drawable.purple_plushy);
        random = new Random();
        resetPosition();
    }

    public Bitmap getPurplushy(int purplushyFrame){
        return purplushy[purplushyFrame];
    }

    public int getPurplushyWidth(){
        return purplushy[0].getWidth();
    }

    public int getPurplushyHeight(){
        return purplushy[0].getHeight();
    }

    public void resetPosition(){
        purplushyX = random.nextInt(GameView.dWidth - getPurplushyWidth());
        purplushyY = -8000 + random.nextInt(2500) * -1;
        purplushyVelocity = 15 + random.nextInt(8);
    }
}
