package com.example.save_the_plushy;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class DBHandler extends SQLiteOpenHelper {

    private static final String DB_NAME = "LEADERBOARDDB";

    // below int is our database version
    private static final int DB_VERSION = 1;

    // below variable is for our table name.
    private static final String TABLE_NAME = "leaderboard";

    // below variable is for our id column.
    private static final String ID_COL = "id";

    // below variable is for our course name column
    private static final String USERNAME_COL = "username";

    // below variable id for our course duration column.
    private static final String SCORE_COL = "score";

    // creating a constructor for our database handler.
    public DBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // below method is for creating a database by running a sqlite query
    @Override
    public void onCreate(SQLiteDatabase db) {
        // on below line we are creating
        // an sqlite query and we are
        // setting our column names
        // along with their data types.
        String query = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + USERNAME_COL + " TEXT,"
                + SCORE_COL + " TEXT)";

        // at last we are calling a exec sql
        // method to execute above sql query
        db.execSQL(query);
    }

    // this method is use to add new user to our sqlite database.
    public void addNewUser(String userName, String userScore) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if the player already exists in the database.
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " + USERNAME_COL + " = ?", new String[]{userName});

        if (cursor.moveToFirst()) {
            // Player exists in the database.
            int currentScore = Integer.parseInt(cursor.getString(cursor.getColumnIndex(SCORE_COL)));
            int newScore = Integer.parseInt(userScore);

            // Compare the new score with the existing score.
            if (newScore > currentScore) {
                // Update the score as it's a new personal best.
                ContentValues values = new ContentValues();
                values.put(SCORE_COL, userScore);
                db.update(TABLE_NAME, values, USERNAME_COL + " = ?", new String[]{userName});
            }
        } else {
            // Player doesn't exist, so add a new row to the database.
            ContentValues values = new ContentValues();
            values.put(USERNAME_COL, userName);
            values.put(SCORE_COL, userScore);
            db.insert(TABLE_NAME, null, values);
        }

        cursor.close();
        db.close();
    }


    // we have created a new method for reading all the courses.
    public ArrayList<LeaderboardModal> readLeaderboard() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursorLeaderboard = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
        ArrayList<LeaderboardModal> leaderboardModalArrayList = new ArrayList<>();

        if (cursorLeaderboard.moveToFirst()) {
            int position = 1;
            do {
                String userName = cursorLeaderboard.getString(1);
                String score = cursorLeaderboard.getString(2);

                // Create the LeaderboardModal object and set the position.
                LeaderboardModal modal = new LeaderboardModal(userName, score);
                modal.setPosition(position); // Set the position without auto-incrementing.

                // Add the LeaderboardModal object to the list.
                leaderboardModalArrayList.add(modal);
                position++; // Increment the position counter for the next record.
            } while (cursorLeaderboard.moveToNext());
        }
        cursorLeaderboard.close();

        // Sort the list based on the score field using a custom comparator.
        Collections.sort(leaderboardModalArrayList, new Comparator<LeaderboardModal>() {
            @Override
            public int compare(LeaderboardModal o1, LeaderboardModal o2) {
                // Convert the score strings to integers and compare.
                int score1 = Integer.parseInt(o1.getScore());
                int score2 = Integer.parseInt(o2.getScore());
                // Swap the order (descending) to have the highest score first.
                return Integer.compare(score2, score1);
            }
        });

        // Update the positions in the sorted list for display.
        for (int i = 0; i < leaderboardModalArrayList.size(); i++) {
            leaderboardModalArrayList.get(i).setPosition(i + 1);
        }

        // Log the sorted and updated leaderboard for debugging.
        for (LeaderboardModal modal : leaderboardModalArrayList) {
            Log.d("LeaderboardData", "Position: " + modal.getPosition() + ", UserName: " + modal.getUserName() + ", Score: " + modal.getScore());
        }

        return leaderboardModalArrayList;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // this method is called to check if the table exists already.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}

