package com.example.save_the_plushy;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ViewLeaderboard extends AppCompatActivity {
    // creating variables for our array list,
    // dbhandler, adapter and recycler view.
    private ArrayList<LeaderboardModal> leaderboardModalArrayList;
    private DBHandler dbHandler;
    private LeaderBoardRVAdapter leaderboardRVAdapter;
    private RecyclerView leaderboardRV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leader_board);
        Log.d("ViewLeaderboard", "onCreate method is called.");
        // initializing our all variables.
        leaderboardModalArrayList = new ArrayList<>();
        dbHandler = new DBHandler(ViewLeaderboard.this);

        // getting our course array
        // list from db handler class.
        leaderboardModalArrayList = dbHandler.readLeaderboard();
        /*Collections.sort(leaderboardModalArrayList, new Comparator<LeaderboardModal>() {
            @Override
            public int compare(LeaderboardModal o1, LeaderboardModal o2) {
                // Convert the scores to integers before comparing
                int score1 = Integer.parseInt(o1.getScore());
                int score2 = Integer.parseInt(o2.getScore());

                // Compare the scores in descending order
                // (use score2 - score1 for ascending order)
                return Integer.compare(score2, score1);
            }
        });*/

        leaderboardModalArrayList.add(0, new LeaderboardModal("USERNAME","SCORE"));

        // on below line passing our array list to our adapter class.
        leaderboardRVAdapter = new LeaderBoardRVAdapter(leaderboardModalArrayList, ViewLeaderboard.this);
        leaderboardRV = findViewById(R.id.idRVLeaderboard);

        // setting our adapter to recycler view.
        leaderboardRV.setAdapter(leaderboardRVAdapter);

        // setting layout manager for our recycler view.
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(ViewLeaderboard.this, RecyclerView.VERTICAL, false);
        leaderboardRV.setLayoutManager(linearLayoutManager);
    }

    public void btn_backToGameOver(View view) {
        // Finish the current activity to navigate back to the previous activity (game_over).
        finish();
    }
}
