package com.example.save_the_plushy;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.util.Random;

public class Quby {
    Bitmap quby[] = new Bitmap[2];
    int qubyFrame = 0;
    int qubyX, qubyY, qubyVelocity;
    Random random;

    public void setQubyY(int newY) {
        qubyY = newY + random.nextInt(5000) * -1;
    }

    public Quby(Context context){
        quby[0] = BitmapFactory.decodeResource(context.getResources(), R.drawable.quby);
        random = new Random();
        resetPosition();
    }

    public Bitmap getQuby(int qubyFrame){
        return quby[qubyFrame];
    }

    public int getQubyWidth(){
        return quby[0].getWidth();
    }

    public int getQubyHeight(){
        return quby[0].getHeight();
    }

    public void resetPosition() {
        resetPosition(20000);
    }
    public void resetPosition(int customQubyY){
        qubyX = random.nextInt(GameView.dWidth - getQubyWidth());
        qubyY = -customQubyY + random.nextInt(5000) * -1;
        qubyVelocity = 50 + random.nextInt(16);
    }
}
